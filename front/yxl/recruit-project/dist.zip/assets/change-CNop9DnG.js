import{_ as c}from"./index-CUMi0BMv.js";const e={};function r(n,s){return"changepassword"}const _=c(e,[["render",r]]);export{_ as default};
